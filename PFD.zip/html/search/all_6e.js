var searchData=
[
  ['num_5fdeps',['num_deps',['../structVertex.html#ad7dd346cc42a287a63aa26069970c550',1,'Vertex']]],
  ['number',['number',['../structVertex.html#a57602368a7700536c61c380411c51b7f',1,'Vertex']]]
];
