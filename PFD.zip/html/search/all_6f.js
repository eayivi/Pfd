var searchData=
[
  ['operator_3c',['operator<',['../PFD_8c_09_09.html#a77d6fb07407a6840377f58c99695a83e',1,'operator&lt;(const Vertex &amp;x, const Vertex &amp;y):&#160;PFD.c++'],['../SpherePFD_8c_09_09.html#a77d6fb07407a6840377f58c99695a83e',1,'operator&lt;(const Vertex &amp;x, const Vertex &amp;y):&#160;SpherePFD.c++']]]
];
